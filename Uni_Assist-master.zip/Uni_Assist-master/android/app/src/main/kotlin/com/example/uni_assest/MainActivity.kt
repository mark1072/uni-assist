package com.example.uni_assest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
